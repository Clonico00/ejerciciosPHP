<?php
echo "<h2>Bienvenido</h2>";
echo "<a href='login.php'>Volver a la pagina de login</a>";